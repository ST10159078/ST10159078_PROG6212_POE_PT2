using System;

namespace CalculateModule
{
    public class Class1
    {
    }
}
