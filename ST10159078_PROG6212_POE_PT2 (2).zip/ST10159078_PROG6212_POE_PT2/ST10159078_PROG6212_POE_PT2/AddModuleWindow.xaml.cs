﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ST10159078_PROG6212_POE_PT2
{
    /// <summary>
    /// Interaction logic for AddModuleWindow.xaml
    /// </summary>
    public partial class AddModuleWindow : Window
    {
        SqlConnection con = new SqlConnection("Server = lab000000\\SQLEXPRESS; Database=POE;Integrated Security = True;");
        public string username;
        public int userID;
        module mod = new module();

        public AddModuleWindow(string loggedInUsername)
        {
            InitializeComponent();
            username = loggedInUsername;

            //when the form loads the db should pull
            bindGridView();
            con = new SqlConnection(@"Data Source = lab000000\SQLEXPRESS; Initial Catalog = POE; Integrated Security = True");
        }

        public void bindGridView()
        {
            // Use the current user's UserID to filter the data
            int currentUserID = GetUserId(username);

            POEEntities poe = new POEEntities();
            var userResults = from u in poe.modules
                              where u.UserId == currentUserID
                              select new { u.moduleID, u.moduleCode, u.moduleName, u.No_ofCredits, u.Hours, u.startDate, u.Weeks, u.SelfStudyHours };
            Datagrid1.ItemsSource = userResults.ToList();
        }


        // Go back to login screen
        private void bt9_Click(object sender, RoutedEventArgs e)
        {
            LoginPage login = new LoginPage();
            login.Show();
            this.Close();
        }

        private void bt10_Click(object sender, RoutedEventArgs e)
        {
            // Close application
            this.Close();
        }

        private void Datagrid1_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

        }

        private bool AuthenticateUser(string username, string password)
        {
            using (POEEntities poe = new POEEntities())
            {
                // Replace 'users' with the actual DbSet name of your user table
                var user = poe.users.FirstOrDefault(u => u.Username == username && u.PasswordHash == password);
                return user != null; // Return true if the user exists with the provided username and password
            }
        }

        // Get the UserId for the authenticated user
        private int GetUserId(string username)
        {
            using (POEEntities poe = new POEEntities())
            {
                // Replace 'users' with the actual DbSet name of your user table
                var user = poe.users.FirstOrDefault(u => u.Username == username);
                return user != null ? user.UserId : 0; // Return the UserId if the user exists, or 0 if not found
            }
        }

        // Insert into the datagrid
        private void bt5_Click(object sender, RoutedEventArgs e)
        {
            POEEntities poe = new POEEntities();
            //validation 
            if (tb6.Text.Length == 0 || tb7.Text.Length == 0 || tb8.Text.Length == 0 || tb9.Text.Length == 0)
            {
                MessageBox.Show("Fields cannot be Left Blank >>>>");
            }
            else
            {
                // confirm if entry is correct before sending to the Datagrid
                if (MessageBox.Show("Is the entry correct?", "Cofirm Entry", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    SqlCommand sqlCommand = new SqlCommand("Select UserId FROM users WHERE Username = @Username", con);
                    sqlCommand.CommandType = System.Data.CommandType.Text;
                    sqlCommand.Parameters.AddWithValue("@Username", username);
                    con.Open();
                    var userId = sqlCommand.ExecuteScalar();
                    mod.UserId = poe.users.Where(u => u.Username == username).Select(u => u.UserId).First();
                    con.Close();

                    mod.moduleName = tb7.Text;
                    mod.moduleCode = tb6.Text;
                    mod.No_ofCredits = Convert.ToInt32(this.tb8.Text);
                    mod.Hours = Convert.ToInt32(this.tb9.Text);
                    mod.startDate = date1.DisplayDate;
                    mod.Weeks = Convert.ToInt32(tb10.Text);
                    mod.SelfStudyHours = CalculateModule.SelfStudies(Convert.ToInt32(tb8.Text), Convert.ToInt32(tb10.Text), Convert.ToInt32(tb9.Text));


                    mod.UserId = poe.users.Where(u => u.Username == username).Select(u => u.UserId).First();

                    poe.modules.Add(mod);
                    int a = poe.SaveChanges();
                    if (a > 0)
                    {
                        MessageBox.Show("data added");
                        bindGridView();//refresh
                    }
                    else
                    {
                        MessageBox.Show("Failed ");
                    }

                    bindGridView();



                }



            }
        }

        // To calculate the remaining hours of studying
        private void bt8_Click(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(tb8.Text, out int credits) &&
                int.TryParse(tb10.Text, out int weeks) &&
                int.TryParse(tb9.Text, out int classHours))
            {
                mod.SelfStudyHours = CalculateModule.SelfStudies(credits, weeks, classHours);
                mod.remain = CalculateModule.remainingHours(mod.SelfStudyHours, int.Parse(tb11.Text)); // You can use int.Parse() here.

                tb12.Text = Convert.ToString(mod.remain);
            }
            else
            {
                MessageBox.Show("Invalid input. Please enter valid numbers for Credits, Weeks, and Class Hours.");
            }
        }
    }
}
