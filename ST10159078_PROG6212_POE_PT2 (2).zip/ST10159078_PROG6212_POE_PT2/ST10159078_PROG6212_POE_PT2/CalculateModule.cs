﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10159078_PROG6212_POE_PT2
{
    public class CalculateModule
    {
        public static int SelfStudies(int credit, int weeks, int classHoursPerWeek)
        {
            int selfStudyHoursPerWeek = credit * 10 / weeks - classHoursPerWeek;
            // Ensure self-study hours are non-negative
            return Math.Max(selfStudyHoursPerWeek, 0);
        }

        public static int remainingHours(int selfStudyHoursPerWeek, int hoursStudied)
        {
            return selfStudyHoursPerWeek - hoursStudied;
        }
    }
}


