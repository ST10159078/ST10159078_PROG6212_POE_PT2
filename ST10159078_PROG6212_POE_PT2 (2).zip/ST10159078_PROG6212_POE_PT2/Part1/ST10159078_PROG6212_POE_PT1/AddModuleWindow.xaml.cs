﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ST10159078_PROG6212_POE_PT1
{
    /// <summary>
    /// Interaction logic for AddModuleWindow.xaml
    /// </summary>
    public partial class AddModuleWindow : Window
    {
        List<Module> modules = new List<Module>();
        List<Module> filtered;
        public Module md = new Module();
        public AddModuleWindow()
        {
            InitializeComponent();
        }
        public class Module
        {
            public string moduleName { get; set; }
            public string moduleCode { get; set; }
            public int No_ofCredits { get; set; }
            public int Hours { get; set; }
            public int Weeks { get; set; }
            public string startDate { get; set; }
            public int self { get; set; }
            public int remain { get; set; }
            public int SelfStudyHours { get; set; }
            public List<StudyRecord> StudyRecords { get; set; } = new List<StudyRecord>();

        }
        public class StudyRecord
        {
            public DateTime Date { get; set; }
            public int HoursStudied { get; set; }
            public int RemainingHours { get; set; }
        }

        private void bt1_Click(object sender, RoutedEventArgs e)
        {
            //validation 
            if (tb1.Text.Length == 0 || tb2.Text.Length == 0 || tb3.Text.Length == 0 || tb4.Text.Length == 0)
            {
                MessageBox.Show("Fields cannot be Left Blank >>>>");
            }
            else
            {
                // confirm if entry is correct before sending to the Datagrid
                if (MessageBox.Show("Is the entry correct?", "Cofirm Entry", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    // pull info from the boxes
                    Module md = new Module();
                    md.moduleName = tb2.Text;
                    md.moduleCode = tb1.Text;
                    md.No_ofCredits = Convert.ToInt32(this.tb3.Text);
                    md.Hours = Convert.ToInt32(this.tb4.Text);

                    cb1.Items.Add(md.moduleCode);
                    //cbModuleSelection.Items.Add(md.moduleCode);

                    modules.Add(md);



                    //Info from the text boxes are added into the datagrid
                    Datagrid1.Items.Add(md);

                    //Clear all the textboxes
                    //tb1.Text = "";
                    //tb2.Text = "";
                    //tb3.Text = "";
                    //tb4.Text = "";
                }
            }
        }
        private void bt2_Click(object sender, RoutedEventArgs e)
        {
            // Clear all data from the datagrid
            Datagrid1.Items.Clear();
        }
        private void bt4_Click(object sender, RoutedEventArgs e)
        {
            // pull info from the boxes
            Module md = new Module();
            var selfStudyHoursPerWeek = new StudyCalculator();

            md.Weeks = Convert.ToInt32(this.tb5.Text);
            md.startDate = date1.Text;
            md.moduleCode = cb1.Text;
            md.self = selfStudyHoursPerWeek.CalculateSelfStudyHours(Convert.ToInt32(tb3.Text), Convert.ToInt32(tb5.Text), Convert.ToInt32(tb4.Text));

            Datagrid2.Items.Add(md);
        }
        private void bt6_Click(object sender, RoutedEventArgs e)
        {
            var studyCalculator = new StudyCalculator();
            Module md = new Module();

            md.self = studyCalculator.CalculateSelfStudyHours(Convert.ToInt32(tb3.Text), Convert.ToInt32(tb5.Text), Convert.ToInt32(tb4.Text));
            md.remain = studyCalculator.CalculateRemainingHours(md.self, Convert.ToInt32(tb6.Text));

            tb7.Text = Convert.ToString(md.remain);
        }
        private void Next_Click(object sender, RoutedEventArgs e)
        {
            // Navigate to the View All Information with Self-Study Calculation Window
            this.Close();
        }
        private void Back_Click_1(object sender, RoutedEventArgs e)
        {
            // Navigate to the Login Window
            var LoginWindow = new LoginWindow();
            LoginWindow.Show();
            this.Close();
        }
        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {            
            Datagrid1.Items.Clear();
            ComboBoxItem cbi = (ComboBoxItem)cb2.SelectedItem;

            //filter by code 
            if (cb2.SelectedItem != null)
            {
                string opt = cbi.Content.ToString();
                switch (opt)
                {
                    //filter by ascending order
                    case "Ascending order by Module Name":
                        filtered = modules.OrderBy(md => md.moduleName).ToList();

                        //using linq
                        filtered = (from f in modules
                                    orderby f.moduleName
                                    select f).ToList();
                        foreach (Module m in filtered)
                        {
                            Datagrid1.Items.Add(m);
                        }
                        break;

                        //filter by descending order
                    case "Descending Order by Hours per Week":
                        filtered = modules.OrderBy(md => md.Hours).ToList();
                        filtered = (from f in modules
                                    orderby f.moduleName
                                    select f).ToList();
                        foreach (Module m in filtered)
                        {
                            Datagrid1.Items.Add(m);
                        }
                        break;
                }
            }
        }

        private void cb1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
        private void Datagrid1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}

