﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ST10159078_PROG6212_POE_PT1
{
    /// <summary>
    /// Interaction logic for RegistrationPage.xaml
    /// </summary>
    public partial class RegistrationPage : Window
    {
        private const string ConnectionString = "Server=lab000000\\SQLEXPRESS;Database=Testing;Integrated Security=True;";

        public RegistrationPage()
        {
            InitializeComponent();
        }
        private void button_Click(object sender, RoutedEventArgs e)
        {
            string firstName = FirstNametxt.Text;
            string lastName = LastNametxt.Text;
            string username = Usernametxt.Text;
            string password = Passwordtxt.Text;

            // Hash the password
            string hashedPassword = ComputeHash(password);

            // Insert the user data into the database
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                try
                {
                    connection.Open();

                    // SQL query to insert user data into the database
                    string query = "INSERT INTO Peeps (FirstName, LastName, Username, PasswordHash) " +
                                   "VALUES (@FirstName, @LastName, @Username, @PasswordHash)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Add parameters to the SQL query to avoid SQL injection
                        command.Parameters.AddWithValue("@FirstName", firstName);
                        command.Parameters.AddWithValue("@LastName", lastName);
                        command.Parameters.AddWithValue("@Username", username);
                        command.Parameters.AddWithValue("@PasswordHash", hashedPassword);

                        //// Execute the SQL command to insert the user data
                        command.ExecuteNonQuery();

                        // Show a success message
                        MessageBox.Show("User registered successfully!");

                        //directed to login page
                        LoginPage loginPage = new LoginPage();
                        loginPage.Show();
                        this.Close();
                    }
                }
                catch (Exception ex)
                {
                    // // Handle any exceptions that may occur during the database operation
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }
        // Helper method to compute the SHA-256 hash of the password
        private string ComputeHash(string input)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                // Compute the hash of the input password
                byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(input));
                StringBuilder builder = new StringBuilder();

                // Convert the hash bytes to a hexadecimal string
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    builder.Append(hashBytes[i].ToString("x2"));
                }

                return builder.ToString();// Return the hashed password as a string
            }
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            // Navigate to the login page
            LoginPage loginPage = new LoginPage();
            loginPage.Show();
            this.Close();
        }
    }
}
