﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ST10159078_PROG6212_POE_PT1
{
    /// <summary>
    /// Interaction logic for LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Window
    {
        private const string ConnectionString = "Server=lab000000\\SQLEXPRESS;Database=Testing;Integrated Security=True;";

        public LoginPage()
        {
            InitializeComponent();
        }
        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordBox.Password;

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                try
                {
                    connection.Open();

                    // SQL query to retrieve the user's data based on the entered username
                    string query = "SELECT PasswordHash FROM Peeps WHERE Username = @Username";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Username", username);

                        SqlDataReader reader = command.ExecuteReader();

                        if (reader.Read())
                        {
                            string storedHashedPassword = reader["PasswordHash"].ToString();

                            // Hash the entered password
                            string enteredHashedPassword = ComputeHash(password);

                            // Compare the entered hashed password with the stored hashed password
                            if (storedHashedPassword == enteredHashedPassword)
                            {
                                MessageBox.Show("Login successful!");
                                // You can navigate to the main application window or perform other actions here.

                                // Navigate to the Add Module and Semester Details Window
                                var addModuleWindow = new AddModuleWindow();
                                addModuleWindow.Show();
                                this.Close();
                            }
                            else
                            {
                                MessageBox.Show("Invalid password.");
                            }
                        }
                        else
                        {
                            MessageBox.Show("User not found.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

        // Helper method to compute the SHA-256 hash of the password
        private string ComputeHash(string input)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                // Compute the hash of the input password
                byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(input));
                StringBuilder builder = new StringBuilder();

                // Convert the hash bytes to a hexadecimal string
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    builder.Append(hashBytes[i].ToString("x2"));
                }

                return builder.ToString();// Return the hashed password as a string
            }
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            // Navigate to the registration page
            RegistrationPage registrationPage = new RegistrationPage();
            registrationPage.Show();
            this.Close();
        }
    }
}
