﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10159078_PROG6212_POE_PT1
{
    public class User
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string HashPassword { get; set; }
        public List<Module> Modules { get; set; }
    }
}
