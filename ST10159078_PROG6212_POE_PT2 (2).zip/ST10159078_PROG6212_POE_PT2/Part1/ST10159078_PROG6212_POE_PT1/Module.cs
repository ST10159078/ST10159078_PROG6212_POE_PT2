﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10159078_PROG6212_POE_PT1
{
    public class Module
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public int Credits { get; set; }
        public int ClassHoursPerWeek { get; set; }
    }

    public class StudyCalculator
    {
        public int CalculateSelfStudyHours(int credits, int weeks, int classHoursPerWeek)
        {
            // Calculate self-study hours using the formula
            int selfStudyHoursPerWeek = (credits * 10) / weeks - classHoursPerWeek;

            // Ensure self-study hours are non-negative
            return Math.Max(selfStudyHoursPerWeek, 0);
        }

        public int CalculateRemainingHours(int selfStudyHoursPerWeek, int hoursStudied)
        {
            // Calculate remaining hours (self-study - hours studied)
            return selfStudyHoursPerWeek - hoursStudied;
        }
    }

}
