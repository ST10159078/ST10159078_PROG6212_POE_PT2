﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10159078_PROG6212_POE_PT1
{
    public class dbModule
    {
        public int ModuleId { get; set; }
        public string ModuleCode { get; set; }
        public int Credits { get; set; }
        public int Hrs { get; set; }
        public DateTime StartDate { get; set; }
        public int Weeks { get; set; }
        public int StudyHrs { get; set; }
        public int Remain { get; set; }
        public int UserId { get; set; }
        public User User { get; set; }
    }
}
